-- CreateEnum
CREATE TYPE "SchoolLevel" AS ENUM ('ES', 'JHS', 'JHS_SHS', 'SHS');

-- CreateEnum
CREATE TYPE "SubmissionStatus" AS ENUM ('NOT_SUBMITTED', 'SUBMITTED', 'LATE');

-- CreateEnum
CREATE TYPE "Role" AS ENUM ('ADMIN', 'SCHOOL', 'GRADE_CHAIRMAN', 'SUPERVISOR');

-- CreateEnum
CREATE TYPE "ExamType" AS ENUM ('DIAGNOSTIC_TEST', 'SUMMATIVE_TEST_1', 'SUMMATIVE_TEST_2', 'END_OF_TERM_EXAM');

-- CreateEnum
CREATE TYPE "DocumentType" AS ENUM ('LOA_RESULT', 'TEST_QUESTIONNAIRE', 'TABLE_OF_SPECIFICATIONS');

-- CreateTable
CREATE TABLE "Cluster" (
    "id" SERIAL NOT NULL,
    "name" TEXT NOT NULL,
    "clusterHeadName" TEXT NOT NULL,
    "clusterConsultant" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Cluster_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "School" (
    "id" SERIAL NOT NULL,
    "schoolIdNumber" TEXT NOT NULL,
    "schoolName" TEXT NOT NULL,
    "schoolHeadName" TEXT,
    "schoolEmail" TEXT,
    "schoolLevel" "SchoolLevel" NOT NULL,
    "clusterId" INTEGER NOT NULL,
    "forceChairmenGoogleSignIn" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "School_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "GradeLevel" (
    "id" SERIAL NOT NULL,
    "schoolId" INTEGER NOT NULL,
    "gradeName" TEXT NOT NULL,

    CONSTRAINT "GradeLevel_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ClassSection" (
    "id" SERIAL NOT NULL,
    "gradeLevelId" INTEGER NOT NULL,
    "className" TEXT NOT NULL,
    "hasElectives" BOOLEAN NOT NULL DEFAULT false,
    "electiveFileTargets" JSONB NOT NULL DEFAULT '{}',

    CONSTRAINT "ClassSection_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "LearningArea" (
    "id" SERIAL NOT NULL,
    "name" TEXT NOT NULL,
    "grade" TEXT NOT NULL,

    CONSTRAINT "LearningArea_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Submission" (
    "id" SERIAL NOT NULL,
    "classSectionId" INTEGER NOT NULL,
    "learningAreaId" INTEGER NOT NULL,
    "termId" INTEGER NOT NULL,
    "examType" "ExamType" NOT NULL DEFAULT 'DIAGNOSTIC_TEST',
    "documentType" "DocumentType" NOT NULL DEFAULT 'LOA_RESULT',
    "fileName" TEXT,
    "filePath" TEXT,
    "status" "SubmissionStatus" NOT NULL DEFAULT 'NOT_SUBMITTED',
    "submittedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Submission_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "SchoolYear" (
    "id" SERIAL NOT NULL,
    "label" TEXT NOT NULL,
    "isActive" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "SchoolYear_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Term" (
    "id" SERIAL NOT NULL,
    "schoolYearId" INTEGER NOT NULL,
    "name" TEXT NOT NULL,
    "isActive" BOOLEAN NOT NULL DEFAULT false,

    CONSTRAINT "Term_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ExamSchedule" (
    "id" SERIAL NOT NULL,
    "termId" INTEGER NOT NULL,
    "examType" "ExamType" NOT NULL,
    "documentType" "DocumentType" NOT NULL DEFAULT 'LOA_RESULT',
    "required" BOOLEAN NOT NULL DEFAULT false,
    "startDate" TIMESTAMP(3),
    "deadline" TIMESTAMP(3),
    "allowedFileTypes" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "allowLateSubmission" BOOLEAN NOT NULL DEFAULT false,
    "enforceOrder" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ExamSchedule_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AuditLog" (
    "id" SERIAL NOT NULL,
    "action" TEXT NOT NULL,
    "actorId" INTEGER,
    "actorName" TEXT,
    "actorEmail" TEXT,
    "actorRole" "Role",
    "targetType" TEXT,
    "targetId" INTEGER,
    "details" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "AuditLog_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "User" (
    "id" SERIAL NOT NULL,
    "email" TEXT NOT NULL,
    "passwordHash" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "role" "Role" NOT NULL,
    "schoolId" INTEGER,
    "gradeLevelIds" INTEGER[] DEFAULT ARRAY[]::INTEGER[],
    "multigrade" BOOLEAN NOT NULL DEFAULT false,
    "assignedLearningAreas" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "forceGoogleSignIn" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "User_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "School_schoolIdNumber_key" ON "School"("schoolIdNumber");

-- CreateIndex
CREATE UNIQUE INDEX "GradeLevel_schoolId_gradeName_key" ON "GradeLevel"("schoolId", "gradeName");

-- CreateIndex
CREATE UNIQUE INDEX "ClassSection_gradeLevelId_className_key" ON "ClassSection"("gradeLevelId", "className");

-- CreateIndex
CREATE UNIQUE INDEX "LearningArea_name_grade_key" ON "LearningArea"("name", "grade");

-- CreateIndex
CREATE INDEX "Submission_classSectionId_learningAreaId_termId_examType_do_idx" ON "Submission"("classSectionId", "learningAreaId", "termId", "examType", "documentType");

-- CreateIndex
CREATE UNIQUE INDEX "SchoolYear_label_key" ON "SchoolYear"("label");

-- CreateIndex
CREATE UNIQUE INDEX "Term_schoolYearId_name_key" ON "Term"("schoolYearId", "name");

-- CreateIndex
CREATE UNIQUE INDEX "ExamSchedule_termId_examType_documentType_key" ON "ExamSchedule"("termId", "examType", "documentType");

-- CreateIndex
CREATE INDEX "AuditLog_createdAt_idx" ON "AuditLog"("createdAt");

-- CreateIndex
CREATE INDEX "AuditLog_action_idx" ON "AuditLog"("action");

-- CreateIndex
CREATE UNIQUE INDEX "User_email_key" ON "User"("email");

-- AddForeignKey
ALTER TABLE "School" ADD CONSTRAINT "School_clusterId_fkey" FOREIGN KEY ("clusterId") REFERENCES "Cluster"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "GradeLevel" ADD CONSTRAINT "GradeLevel_schoolId_fkey" FOREIGN KEY ("schoolId") REFERENCES "School"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ClassSection" ADD CONSTRAINT "ClassSection_gradeLevelId_fkey" FOREIGN KEY ("gradeLevelId") REFERENCES "GradeLevel"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Submission" ADD CONSTRAINT "Submission_classSectionId_fkey" FOREIGN KEY ("classSectionId") REFERENCES "ClassSection"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Submission" ADD CONSTRAINT "Submission_learningAreaId_fkey" FOREIGN KEY ("learningAreaId") REFERENCES "LearningArea"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Submission" ADD CONSTRAINT "Submission_termId_fkey" FOREIGN KEY ("termId") REFERENCES "Term"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Term" ADD CONSTRAINT "Term_schoolYearId_fkey" FOREIGN KEY ("schoolYearId") REFERENCES "SchoolYear"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ExamSchedule" ADD CONSTRAINT "ExamSchedule_termId_fkey" FOREIGN KEY ("termId") REFERENCES "Term"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "User" ADD CONSTRAINT "User_schoolId_fkey" FOREIGN KEY ("schoolId") REFERENCES "School"("id") ON DELETE CASCADE ON UPDATE CASCADE;

