# LOA Submission and Monitoring System — Production Build

This folder is a self-contained deployable build: one Node.js process
serves both the API and the built React app on a single port. Built
2026-09-11 from `main` at commit `68855c2` — includes the per-document-
type Enforce Sequential Order toggle for exam schedules (`ExamSchedule.
enforceOrder`, one new migration since the prior 2026-09-10 build at
`f0bdba6`, applied and verified against a fresh throwaway database), on
top of breadcrumbs, skeleton loading states, and lazy-loaded routes, the
Document Type axis (Test Questionnaire / Table of Specifications),
Force Chairmen Google Sign-In, Multigrade Chairman support, and the
Submission Form/Status of Submission per-document-type page split.

This covers the **schema only** — a fresh, empty database. It does **not**
migrate the real data (schools, submissions, accounts) already on the
development machine's Postgres instance. That's a separate step (a
`pg_dump`/`pg_restore` of the real database) if you actually want this
server to start with your existing real records instead of an empty one —
ask if you want that done instead of / in addition to this.

## What's in here

```
server/
  dist/            compiled backend (run this)
  public/          built React frontend, served by the backend itself
  prisma/
    schema.prisma
    migrations/    the real, ordered migration history
    seed-production.ts   creates one real Admin account + baseline data
  package.json
  package-lock.json
  .env.example     copy to .env and fill in real values
  uploads/         empty — where submitted files land at runtime
database/
  schema.sql       the same schema as one flat SQL script (see below)
```

## 1. Prerequisites on the Windows server

- **Node.js** (LTS — same major version as used to build this, 20.x).
  https://nodejs.org
- **PostgreSQL** (any recent version). https://www.postgresql.org/download/windows/
- Create an empty database for this app, e.g. in `psql`:
  ```sql
  CREATE DATABASE loa_monitoring;
  ```

## 2. Configure environment variables

```
cd server
copy .env.example .env
```
Edit `.env` — set `DATABASE_URL` to the database you just created, and
generate a real `JWT_SECRET` (never reuse the development one):
```
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```
Full explanation of every value is in `.env.example` itself.

## 3. Install dependencies

```
cd server
npm ci
```
(Needs internet access once, to download packages — nothing after this
step does.)

## 4. Apply the database schema

**Recommended** — via Prisma, using the real migration history (this also
means any *future* schema change ships as a new migration you can apply
the same way, without re-running a whole schema from scratch):
```
cd server
npx prisma migrate deploy
```

**Alternative** — if you'd rather hand `database/schema.sql` to whoever
manages the database and have them run it directly (`psql -d loa_monitoring -f schema.sql`,
or paste it into pgAdmin's query tool), that produces the identical schema.
Use **one or the other**, not both — and if you use `schema.sql`, `npx prisma
migrate deploy` won't work correctly afterward for *future* migrations,
since Prisma tracks what it's applied by migration history, not by
inspecting the database's actual tables.

## 5. Create the first real Admin account

There's no self-registration in this app — every account is created by an
existing Admin (or, for Grade Level Chairmen, by their own school). A brand
new database has zero accounts, so the very first one has to be bootstrapped
directly:

```
cd server
set BOOTSTRAP_ADMIN_NAME=Juan Dela Cruz
set BOOTSTRAP_ADMIN_EMAIL=juan.delacruz@deped.gov.ph
set BOOTSTRAP_ADMIN_PASSWORD=a-real-strong-password
npx ts-node prisma/seed-production.ts
```
(`set` here is a Windows `cmd`/PowerShell environment variable, not a value
saved anywhere — nothing is written to a file. Close the terminal after if
you're worried about it lingering in shell history.)

This also creates the baseline reference data the app needs to actually be
usable — Learning Areas for every grade, Clusters 1–10, and one School Year
with its three Terms. It does **not** create any demo schools or fake
submissions — this script is deliberately separate from the project's own
`prisma:seed` script, which is for local development only and creates
exactly that kind of fake data plus a publicly-known demo password.

## 6. Start the server

```
cd server
npm start
```
You should see `Server running on http://localhost:<PORT>`. Open that URL
in a browser — you should land on the login page, and the Admin account
from step 5 should be able to sign in.

**Always start it from inside the `server` folder** (as `npm start` already
does) — submitted files are written to a relative `uploads/` folder next to
`dist/`, and it needs to resolve from there.

Windows doesn't keep a plain `npm start` process alive after you close the
terminal, log out, or reboot. If you need it to survive that, you'll need
to run it under something that manages that for you (Task Scheduler, NSSM,
IIS + iisnode, etc.) — not included here, since this build is just the
runnable app itself.

## 7. Google Sign-In (optional)

Email/password login works immediately with no further setup. If you also
want "Sign in with DepEd Google Account" to work from this server's real
URL, whoever administers the Google Cloud project this Client ID belongs to
needs to add this server's real hostname under **Authorized JavaScript
origins** (Google Cloud Console → APIs & Services → Credentials → this
OAuth Client ID). Google does not accept a raw IP address there, only a
real hostname (or `localhost`) — see the comment in `.env.example` for
more detail. Until that's done, the Google button still renders but shows
a clear error when clicked; nothing else is affected.
